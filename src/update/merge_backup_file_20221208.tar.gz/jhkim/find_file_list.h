#ifndef __find_file_list_h__
#define __find_file_list_h__

FILE_LIST* find_file_list(char *path);
void find_if_number(char* backup_log, int* if_num);

#endif /* __find_file_h__ */
