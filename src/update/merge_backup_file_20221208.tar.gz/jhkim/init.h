#ifndef __init_h__
#define __init_h__

_Bool init(void);
_Bool init_config(void);

#endif /* __init_h__ */
