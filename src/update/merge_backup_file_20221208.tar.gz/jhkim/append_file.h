#ifndef __append_file_h__
#define __append_file_h__

int append_file(char* file, char* output);
int merge(char* path, char* output);

#endif /*__append_file_h__*/

